#!/bin/bash

#SBATCH -J t5-mariano               # nome da tarefa
#SBATCH -o t5-mariano-%j.out        # nome do arquivo de saída (%j se torna jobID), este arquivo pega a saída padrão do terminal
#SBATCH -e t5-mariano-%j.err        # nome do arquivo de erros (%j se torna jobID), este arquivo pega erros gerados pelo script no terminal
#SBATCH -c 16               # número máximo de threads necessárias
#SBATCH -p qCDER            # partição --qCDER (partições disponíveis ao executar `sinfo`)
#SBATCH -t 01:30:00         # tempo máximo necessário (hh:mm:ss) - 1h30min

SIZE=30
TRIALS=50
PROBS=101
NTHREADS=(1 2 4 8 16)
NEXECS=5

module load Compilers/gcc-8.3.0

make clean
make

for i in ${NTHREADS[@]}; do
    export OMP_NUM_THREADS=$i
    #echo $OMP_NUM_THREADS
    echo $OMP_NUM_THREADS "thread(s)" >> times.txt
    for j in $(seq 1 $NEXECS); do
        (time ./virusim $SIZE $TRIALS $PROBS) 2>&1 > /dev/null | grep real | awk '{print $2}' >> times.txt
    done
    echo -e "\n" >> times.txt
done

cat times.txt

rm times.txt
