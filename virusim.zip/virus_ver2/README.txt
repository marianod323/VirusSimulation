Uso: virusim <tamanho-da-populacao> <nro. experimentos> <probab. maxima>
Exemplo: virusim 30 5000 101 
